/** Only allow ordinary HTTPS store links; never treat a store redirect as payment confirmation. */
export function safeExternalStoreUrl(value: string | null | undefined): string | null {
  if (!value) return null;
  try {
    const url = new URL(value.trim());
    if (url.protocol !== 'https:' || !url.hostname || url.username || url.password) return null;
    if (url.hostname === 'localhost' || url.hostname.endsWith('.localhost')) return null;
    return url.href;
  } catch { return null; }
}
